# `PAC-ANBERNIC` *by* `tenlevels`

PAC-MAN theme inspired by PAC-MAN game 
(originally a gift for my son to enjoy on his Anbernic)


## Credits

**PAC-MAN:** All name and assets from arcade game sprite sheets - modied logo by me

**FONT:** Retro Gaming - Modified for all caps

**APP ICONS:** Pixel icons from Streamlinehq.com

**CONSOLE ICONS:** Mini Icons by Jeltron and Dot-art by Yoshi-kun - sizing and orirentation adjust by Aemiii91

**BACKGROUND MUSIC AND SOUND** PAC-MAN game sounds - files edited by Aemiii91



## Special Thanks

Thank you Aemiii91 for always helping me with my themes, OnionOS and being such an inspiration in the community.